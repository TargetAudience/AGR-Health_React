# end-product-frontend-things

This library is intend to have the custom components associated to things.

Folder structure

- end-product
  - frontend
    - things
      - marimba
        - play-modal.js
        - add-modal.js

this is a react component oriented library and is also intend to custom code, all the written code on here is not going to be regenerated on export code in authoring.

## Running unit tests

Run `nx test end-product-frontend-things` to execute the unit tests via [Jest](https://jestjs.io).
