# elements

This library can provide Input and Display components given some parameters like the Statistical Data Type (sdt).

It can be used to look for the proper element to request data for a filter by looking at the sdt and the operation (equals, exists, etc).

## Running unit tests

Run `nx test elements` to execute the unit tests via [Jest](https://jestjs.io).
