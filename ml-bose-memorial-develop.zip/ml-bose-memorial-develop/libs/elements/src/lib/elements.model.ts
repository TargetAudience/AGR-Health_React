import { FilterOperation } from '@kleeen/types';

export interface GetFilterElementProps {
  filterOperator: FilterOperation;
  thingName: string;
}
