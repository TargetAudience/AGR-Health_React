module.exports = {
  stories: [],
  addons: ['@storybook/addon-essentials'],
};
