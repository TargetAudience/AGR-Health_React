export const pageIntroSectionAttributes = [];
