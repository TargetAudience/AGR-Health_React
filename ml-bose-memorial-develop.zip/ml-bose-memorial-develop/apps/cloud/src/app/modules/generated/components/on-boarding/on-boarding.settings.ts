import { OnBoardingSettings } from './on-boarding.model';

export const Settings: OnBoardingSettings = undefined;
