import { Translate } from '@kleeen/types';

export interface InvestigateBarProps {
  logo?: string;
  onClose: () => void;
  title: string;
  translate: Translate;
}
