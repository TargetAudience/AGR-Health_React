import { Translate } from '@kleeen/types';

export interface InvestigateProps {
  translate: Translate;
}
