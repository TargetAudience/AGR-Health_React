import { ReactElement } from '@kleeen/types';

export interface PreviewPanelProps {
  children: ReactElement;
}
