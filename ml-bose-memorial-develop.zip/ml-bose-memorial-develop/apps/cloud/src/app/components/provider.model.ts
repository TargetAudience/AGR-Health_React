import { ReactNode } from 'react';

export type ProviderProps = {
  children: ReactNode;
};
