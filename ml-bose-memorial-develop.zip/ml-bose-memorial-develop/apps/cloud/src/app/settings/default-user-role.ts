export const DEFAULT_ROLE = 'GUEST';
