/**
 * This file contains polyfills loaded on all browsers
 **/
(window as any).global = window;
