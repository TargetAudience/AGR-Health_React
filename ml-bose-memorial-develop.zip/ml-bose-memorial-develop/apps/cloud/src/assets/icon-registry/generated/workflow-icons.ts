export default {
  // Navigation Icon for Find A Doctor
  'ks-navigation-6Rncjxzo62LhnqmgWbgtHG': {
    path: './assets/icons/wifi-signal-2.svg',
    alt: 'Navigation Icon',
  },
  // Navigation Icon for Member Details
  'ks-navigation-tgTfDvwDK8Z3JzpBdchsTY': {
    path: './assets/icons/house-entrance-alternate.svg',
    alt: 'Navigation Icon',
  },
  // Navigation Icon for Registration
  'ks-navigation-udxLHMgGqsDTn3uwFZS75A': {
    path: './assets/icons/alarm-clock-1-alternate.svg',
    alt: 'Navigation Icon',
  },
  // Navigation Icon for Doctor Details
  'ks-navigation-vd99psxxRvZh9fKo8NAL3q': {
    path: './assets/icons/pie-line-graph-desktop.svg',
    alt: 'Navigation Icon',
  },
};
