import workflowIcons from './workflow-icons';
import viewIcons from './view-icons';

export default {
  ...workflowIcons,
  ...viewIcons,
};
