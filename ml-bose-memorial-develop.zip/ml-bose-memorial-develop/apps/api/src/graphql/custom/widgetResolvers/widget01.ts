import { GetWidgetDataResult, DataAggregationArgs } from '../../../types';

export const widget01 = async (
  input: DataAggregationArgs,
): Promise<GetWidgetDataResult | 'not implemented'> => {
  // TODO: add your code here.
  return 'not implemented';
};
